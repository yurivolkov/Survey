export const CHECK = 'CHECK';
export const REGISTER = 'REGISTER';
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const ROLES = 'ROLES';

export default {
  CHECK,
  REGISTER,
  LOGIN,
  LOGOUT,
  ROLES
};
