export default {
  authenticated: false,
  roles: null
};
