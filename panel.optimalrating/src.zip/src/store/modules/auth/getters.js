export default {
  checkAuthentication: (state) => {
    return state.authenticated;
  },
};
