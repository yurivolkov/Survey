export default {
    settings: null,
    language:'tr-tr',
    country : [],
};
