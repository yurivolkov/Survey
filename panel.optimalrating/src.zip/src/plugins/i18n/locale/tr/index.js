import * as auth from './auth.json';
import * as messages from './messages.json';
import * as common from './common.json';


export default {
  auth,
  messages,
  common,

};
