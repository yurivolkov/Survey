export default {
  /* HeaderSettings/index.vue */
  'Apply': 'Apply and backup settings to local',
  'Apply and backup settings to local': 'Apply and backup settings to local',
  'Clear local settings backup and restore': 'Clear local settings backup and restore',
  'Using local settings': 'Using local settings',

  /* Table/TableBody.vue */
  'No Data': 'No Data',

  /* index.vue */
  'Total': 'Total',
  ',': 'Record，',

  /* PageSizeSelect.vue */
  'items / page': 'record / page'
}
